import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeaturedVideo from './components/FeaturedVideo';
import Videos from './components/Videos';
import About from './components/About';
import Services from './components/Services';
import CTABanner from './components/CTABanner';
import Contact from './components/Contact';
import Footer from './components/Footer';
import LegalPage from './components/LegalPage';
import AlbumsPage from './components/AlbumsPage';
import OrderFormPage from './components/OrderFormPage';

function ScrollToTop() {
  const { pathname, hash } = useLocation();

  useEffect(() => {
    if (!hash) {
      window.scrollTo(0, 0);
    } else {
      const id = hash.replace('#', '');
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [pathname, hash]);

  return null;
}

import CustomizeSong from './components/CustomizeSong';

function Home() {
  return (
    <main>
      <Hero />
      <FeaturedVideo />
      <Videos />
      <About />
      <Services />
      <CustomizeSong />
      <CTABanner />
      <Contact />
    </main>
  );
}

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen bg-brand-black text-white font-sans selection:bg-brand-gold selection:text-black">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/legal" element={<LegalPage />} />
          <Route path="/albums" element={<AlbumsPage />} />
          <Route path="/order" element={<OrderFormPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

