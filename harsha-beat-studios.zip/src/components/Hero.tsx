import { motion } from 'motion/react';
import { Play } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-[70vh] lg:min-h-screen flex items-center justify-center overflow-hidden pt-40 pb-10 lg:pt-32 lg:pb-0">
      {/* Background with temple atmosphere gradients */}
      <div className="absolute inset-0 z-0 bg-brand-black">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand-saffron/20 rounded-full blur-[120px] mix-blend-screen animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-brand-gold/10 rounded-full blur-[120px] mix-blend-screen" style={{ animationDelay: '2s', animation: 'pulse 4s infinite' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] md:w-[600px] h-[300px] md:h-[600px] bg-brand-red/10 rounded-full blur-[80px] md:blur-[100px] mix-blend-screen" />
      </div>

      {/* Cinematic overlay (vignette) */}
      <div className="absolute inset-0 z-0 bg-[radial-gradient(ellipse_at_center,transparent_0%,#0B0B0F_80%)] opacity-80 pointer-events-none" />

      {/* Floating Sparks/Embers */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden hidden md:block">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bg-brand-gold/80 rounded-full blur-[1px]"
            style={{
              width: Math.random() * 4 + 2 + 'px',
              height: Math.random() * 4 + 2 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
            }}
            animate={{
              y: [0, -200],
              x: [(Math.random() - 0.5) * 50, (Math.random() - 0.5) * 100],
              opacity: [0, Math.random() * 0.5 + 0.3, 0],
            }}
            transition={{
              duration: Math.random() * 5 + 5,
              repeat: Infinity,
              ease: "linear",
              delay: Math.random() * 5
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-8 items-center pt-8 pb-16 md:pt-10 md:pb-20">
        
        {/* Left: Content */}
        <div className="text-center lg:text-left flex flex-col items-center lg:items-start">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="inline-block mb-4 md:mb-6 px-4 md:px-5 py-2 rounded-full border border-brand-saffron/30 bg-brand-saffron/10 text-brand-saffron text-[10px] sm:text-xs md:text-sm font-bold tracking-widest uppercase shadow-[0_0_15px_rgba(255,106,0,0.2)]"
          >
            Devotional • Telugu Songs • Beats • Custom Music
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-display font-black uppercase tracking-tighter text-white drop-shadow-[0_0_30px_rgba(255,215,0,0.3)] leading-[0.9] mb-4 md:mb-6"
          >
            AI Music & <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-brand-saffron">Lyrical Video</span> Production Studio
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-zinc-300 text-base md:text-lg lg:text-xl font-light leading-relaxed mb-8 max-w-lg md:max-w-xl mx-auto lg:mx-0"
          >
            Harsha Beat Studios specializes in creating high-quality music tracks, lyrical videos, and cinematic visuals using advanced tools and creative workflows. Our focus is on delivering engaging content for devotional, entertainment, and digital platforms with speed and consistency.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 w-full sm:w-auto"
          >
            <motion.a
              animate={{ boxShadow: ['0 0 20px rgba(255,106,0,0.4)', '0 0 40px rgba(255,106,0,0.8)', '0 0 20px rgba(255,106,0,0.4)'] }}
              transition={{ duration: 2, repeat: Infinity }}
              href="#latest-release"
              className="hidden sm:inline-flex w-full sm:w-auto px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-brand-gold to-brand-saffron text-black font-bold uppercase tracking-wide rounded-full hover:scale-105 transition-all text-center text-sm md:text-base whitespace-nowrap"
            >
              Watch Latest Video
            </motion.a>
            <a
              href="https://youtube.com/@harshabeatstudio"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 md:px-8 py-3 md:py-4 bg-[#FF0000] text-white font-bold rounded-full hover:bg-red-700 transition-all shadow-[0_0_20px_rgba(255,0,0,0.4)] flex items-center justify-center gap-2 md:gap-3 group text-sm md:text-base whitespace-nowrap"
            >
             <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16" className="w-5 h-5 md:w-6 md:h-6 text-white group-hover:scale-110 transition-transform">
                <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.052-.072 1.96l-.01.104-.022.26-.01.104c-.048.519-.119 1.023-.22 1.402a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c1.16-.312 5.569-.334 6.18-.335h.142Z"/>
                <path d="M5.525 6.595v2.81l2.64-1.405-2.64-1.405Z"/>
              </svg>
              Subscribe to YouTube Channel
            </a>
          </motion.div>
        </div>

        {/* Right: Featured Video Thumbnail Area */}
        <div className="w-full max-w-lg lg:ml-auto mt-4 md:mt-0 hidden lg:flex flex-col">
          <motion.div
             initial={{ opacity: 0, scale: 0.8 }}
             animate={{ opacity: 1, scale: 1 }}
             transition={{ duration: 0.8, delay: 0.4, type: "spring" }}
             className="relative aspect-video rounded-2xl md:rounded-3xl overflow-hidden shadow-[0_0_30px_rgba(255,106,0,0.2)] md:shadow-[0_0_50px_rgba(255,106,0,0.3)] border border-brand-gold/20 group cursor-pointer w-full"
          >
            <a href="#latest-release" className="block w-full h-full">
              <img 
                src="https://img.youtube.com/vi/IkAMhF0ijvI/maxresdefault.jpg" 
                alt="Featured Video" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                <div className="w-16 h-16 md:w-20 md:h-20 bg-brand-red/90 text-white rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,0,0,0.5)] group-hover:scale-110 transition-transform">
                  <Play className="ml-1 md:ml-2 fill-current w-8 h-8 md:w-10 md:h-10" />
                </div>
              </div>
              {/* Pulsing rings around play button */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <motion.div 
                   animate={{ scale: [1, 1.5, 2], opacity: [0.8, 0, 0] }}
                   transition={{ duration: 2, repeat: Infinity, ease: "easeOut" }}
                   className="absolute w-16 h-16 md:w-20 md:h-20 rounded-full border-2 border-brand-red"
                 />
                 <motion.div 
                   animate={{ scale: [1, 1.5, 2], opacity: [0.8, 0, 0] }}
                   transition={{ duration: 2, repeat: Infinity, ease: "easeOut", delay: 0.5 }}
                   className="absolute w-16 h-16 md:w-20 md:h-20 rounded-full border border-brand-saffron"
                 />
              </div>
            </a>
          </motion.div>
        </div>

      </div>
    </section>
  );
}
