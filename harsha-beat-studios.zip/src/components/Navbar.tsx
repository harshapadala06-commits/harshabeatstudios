import { motion } from 'motion/react';
import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const links = [
    { name: 'Customize Your Song', path: '/#customize' },
    { name: 'Latest Release', path: '/#latest-release' },
    { name: 'Our Albums', path: '/albums' },
    { name: 'Upcoming Albums', path: '/#our-collection' },
    { name: 'About', path: '/#about' },
    { name: 'Contact', path: '/#contact' }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 flex flex-col">
      {/* Announcement Bar */}
      <a 
        href="https://openinapp.link/4cdpb" 
        target="_blank" 
        rel="noopener noreferrer"
        className="w-full bg-gradient-to-r from-brand-gold to-brand-saffron py-2 px-4 shadow-[0_0_15px_rgba(255,215,0,0.5)] z-50 flex items-center justify-center gap-2 group hover:bg-gradient-to-r hover:from-yellow-400 hover:to-orange-400 transition-all cursor-pointer"
      >
        <span className="text-zinc-950 font-black text-xs md:text-sm tracking-widest uppercase">
          Review us on Google / Support us
        </span>
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="text-zinc-950 group-hover:scale-110 transition-transform" viewBox="0 0 16 16">
          <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
          <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0"/>
        </svg>
      </a>

      {/* Main Navbar */}
      <div className="glass-panel border-b-0 border-white/5 w-full">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          {/* Text Logo styled based on attached image vibe */}
          <div className="font-display font-black text-2xl tracking-tighter uppercase flex items-center">
            <span className="text-transparent bg-clip-text bg-gradient-to-br from-brand-gold to-yellow-600 group-hover:text-glow transition">H</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-br from-brand-blue to-blue-600 drop-shadow-[0_0_10px_rgba(0,194,255,0.4)] transition">B</span>
          </div>
          <div className="flex flex-col ml-2 leading-none">
            <span className="font-display font-bold text-lg tracking-wider">HARSHA BEAT</span>
            <span className="text-[10px] tracking-[0.2em] text-zinc-400 uppercase">Studios</span>
          </div>
        </Link>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-8">
          {links.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className="text-sm font-medium text-zinc-300 hover:text-white transition"
            >
              {link.name}
            </Link>
          ))}
          <a
            href="https://www.youtube.com/@HarshaBeatstudio"
            target="_blank"
            rel="noopener noreferrer"
            className="px-5 py-2.5 rounded-full bg-[#FF0000] text-white font-semibold text-sm hover:bg-[#CC0000] transition-colors flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
              <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.052-.072 1.96l-.01.104-.022.26-.01.104c-.048.519-.119 1.023-.22 1.402a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c1.16-.312 5.569-.334 6.18-.335h.142Z"/>
              <path d="M5.525 6.595v2.81l2.64-1.405-2.64-1.405Z"/>
            </svg>
            Subscribe
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden absolute top-full left-0 right-0 bg-brand-black/95 backdrop-blur-xl border-b border-white/10 px-6 py-6 flex flex-col gap-4"
        >
          {links.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className="text-lg font-medium text-zinc-200 hover:text-brand-gold transition"
              onClick={() => setIsOpen(false)}
            >
              {link.name}
            </Link>
          ))}
        </motion.div>
      )}
    </nav>
  );
}
