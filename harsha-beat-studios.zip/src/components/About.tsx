import { motion } from 'motion/react';
import { Instagram } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-square bg-zinc-900 rounded-3xl overflow-hidden glass-panel relative p-1 shadow-[0_0_40px_rgba(255,106,0,0.15)]">
              <div className="w-full h-full bg-gradient-to-br from-brand-black to-zinc-900 rounded-[22px] flex items-center justify-center relative overflow-hidden">
                {/* Decorative Elements */}
                <div className="absolute w-3/4 h-3/4 border border-brand-gold/20 rounded-full animate-[spin_20s_linear_infinite]" />
                <div className="absolute w-1/2 h-1/2 border border-brand-saffron/20 rounded-full animate-[spin_15s_linear_infinite_reverse]" />
                <div className="absolute inset-0 flex items-center justify-center">
                   <div className="w-32 h-32 bg-brand-saffron blur-[80px] rounded-full opacity-50 animate-pulse" />
                </div>
                
                {/* Actual image placeholder */}
                <img 
                  src="https://images.unsplash.com/photo-1542281286-9e0a16bb7366?q=80&w=2670&auto=format&fit=crop" 
                  alt="Temple Vibe" 
                  className="absolute inset-0 w-full h-full object-cover mix-blend-overlay opacity-80"
                />
              </div>
            </div>
            
            {/* Floating badge */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ repeat: Infinity, duration: 4 }}
              className="absolute -bottom-8 -right-8 glass-panel p-6 rounded-2xl border-white/10 shadow-2xl bg-brand-black/90 backdrop-blur-md"
            >
              <div className="text-4xl font-black text-brand-gold">OM</div>
              <div className="text-sm text-zinc-400 font-medium uppercase tracking-wider mt-1">Divine Sound</div>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex flex-col sm:flex-row sm:items-center gap-6 mb-6">
              <img 
                src="https://yt3.googleusercontent.com/XkjyhoKBco2_NqkdC-yt3DI3l5rczPqc5GoLDJlA2CXHn66V0VJ3LT4PYyNOZF1yf7Y24Avvlg=s160-c-k-c0x00ffffff-no-rj"
                alt="Harsha Beat Studios Logo"
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-full shadow-[0_0_30px_rgba(255,215,0,0.2)] border border-brand-gold/30"
              />
              <h2 className="text-3xl md:text-5xl font-display font-black uppercase tracking-tighter text-white">
                About <br className="hidden lg:block xl:hidden"/> <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-brand-saffron">Harsha Beat Studios</span>
              </h2>
            </div>
            <div className="space-y-6 text-lg text-zinc-300 font-light leading-relaxed">
              <p>Welcome to Harsha Beat Studios 🎧🔥</p>
              <p>
                This is your go-to destination for Telugu songs, original music, folk beats, devotional tracks, and custom-made songs that connect with real emotion and powerful sound.
              </p>
              <div className="py-4">
                <p className="font-bold text-white mb-4 uppercase tracking-wider text-sm">At Harsha Beat Studios, we create:</p>
                <ul className="space-y-3">
                  <li className="flex items-center gap-3"><span className="text-xl">🎵</span> Original Telugu Songs</li>
                  <li className="flex items-center gap-3"><span className="text-xl">🎧</span> High-quality Music Production</li>
                  <li className="flex items-center gap-3"><span className="text-xl">🔥</span> Trending & Viral Style Tracks</li>
                  <li className="flex items-center gap-3"><span className="text-xl">🌿</span> Telugu Folk & Janapada Songs</li>
                  <li className="flex items-center gap-3"><span className="text-xl">🙏</span> Devotional Songs (Bhakti)</li>
                  <li className="flex items-center gap-3"><span className="text-xl">🎤</span> Custom Songs for Events & Creators</li>
                </ul>
              </div>
              <p className="border-l-2 border-brand-saffron pl-6 py-2 text-white italic text-xl font-serif mt-8">
                "Our goal is simple: create music that people feel, not just hear."
              </p>
              <p className="pt-2 font-medium text-brand-gold">
                If you love Telugu music, powerful beats, and unique original content — you're in the right place.
              </p>
              
              <div className="pt-6 border-t border-white/10 mt-6 flex flex-col gap-3">
                <p className="text-zinc-300 font-medium text-lg">Founder: <strong className="text-white font-black tracking-wide">HARSHA PADALA</strong></p>
                <div className="flex flex-col gap-1">
                  <a 
                    href="https://www.instagram.com/im.harshapadala?igsh=MTdpcjZ3YTFwb3dqNw==" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="inline-flex items-center gap-2 text-brand-gold hover:text-brand-saffron transition font-medium w-max group"
                  >
                     <Instagram size={20} className="group-hover:scale-110 transition-transform" />
                     <span>Founder official Instagram page</span>
                  </a>
                  <span className="text-zinc-400 text-sm">Any issues you can directly contact to the Founder directly through Instagram</span>
                </div>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
