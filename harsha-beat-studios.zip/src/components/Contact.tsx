import { Instagram, Youtube, Facebook, Send } from 'lucide-react';
import { motion } from 'motion/react';

export default function Contact() {
  const handleSend = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const email = formData.get('email') as string;
    const projectType = formData.get('projectType') as string;
    const message = formData.get('message') as string;

    const subject = encodeURIComponent(`Collaboration Inquiry: ${projectType}`);
    const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`);

    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    
    if (isMobile) {
      window.location.href = `mailto:harshabeatstudio11@gmail.com?subject=${subject}&body=${body}`;
    } else {
      const mailToURL = `https://mail.google.com/mail/?view=cm&fs=1&to=harshabeatstudio11@gmail.com&su=${subject}&body=${body}`;
      window.open(mailToURL, '_blank');
    }
  };

  return (
    <section id="contact" className="py-24 bg-zinc-950 relative border-t border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          <motion.div
             initial={{ opacity: 0, x: -30 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-display font-black uppercase tracking-tighter text-white mb-6 leading-tight text-center md:text-left">
              Collaborate With <span className="text-brand-saffron">Us</span>
            </h2>
            <p className="text-zinc-400 mb-10 text-lg font-light max-w-md mx-auto md:mx-0 text-center md:text-left">
              Whether you are an artist, a temple organization, or a creative mind, let's create something divine together.
            </p>
            
            <div className="flex flex-col gap-6 items-center md:items-start">
              <a href="https://www.youtube.com/@HarshaBeatstudio" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 text-zinc-300 hover:text-brand-gold transition group w-max">
                <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center group-hover:border-brand-gold bg-white/5 shadow-[0_0_15px_rgba(255,215,0,0)] group-hover:shadow-[0_0_15px_rgba(255,215,0,0.2)] transition-shadow">
                  <Youtube size={20} />
                </div>
                <span className="font-medium text-lg">Subscribe on YouTube</span>
              </a>
              <a href="https://www.instagram.com/harshabeatstudios" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 text-zinc-300 hover:text-brand-gold transition group w-max">
                <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center group-hover:border-brand-gold bg-white/5 shadow-[0_0_15px_rgba(255,215,0,0)] group-hover:shadow-[0_0_15px_rgba(255,215,0,0.2)] transition-shadow">
                  <Instagram size={20} />
                </div>
                <span className="font-medium text-lg">Follow on Instagram</span>
              </a>
              <a href="https://www.facebook.com/share/1Kg6n7vc1X/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 text-zinc-300 hover:text-brand-gold transition group w-max">
                <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center group-hover:border-brand-gold bg-white/5 shadow-[0_0_15px_rgba(255,215,0,0)] group-hover:shadow-[0_0_15px_rgba(255,215,0,0.2)] transition-shadow">
                  <Facebook size={20} />
                </div>
                <span className="font-medium text-lg">Follow on Facebook</span>
              </a>
              <a href="https://t.me/harshabeatstudios" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 text-zinc-300 hover:text-brand-gold transition group w-max">
                <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center group-hover:border-brand-gold bg-white/5 shadow-[0_0_15px_rgba(255,215,0,0)] group-hover:shadow-[0_0_15px_rgba(255,215,0,0.2)] transition-shadow pl-1">
                  <Send size={20} />
                </div>
                <span className="font-medium text-lg">Join our Telegram group</span>
              </a>
              <a href="https://x.com/BeatHarsha88872" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 text-zinc-300 hover:text-brand-gold transition group w-max">
                <div className="w-12 h-12 rounded-full border border-white/10 flex items-center justify-center group-hover:border-brand-gold bg-white/5 shadow-[0_0_15px_rgba(255,215,0,0)] group-hover:shadow-[0_0_15px_rgba(255,215,0,0.2)] transition-shadow">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16" className="transform transition-transform group-hover:scale-110">
                    <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z"/>
                  </svg>
                </div>
                <span className="font-medium text-lg">Follow on X</span>
              </a>
            </div>
          </motion.div>

          <motion.div
             initial={{ opacity: 0, x: 30 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             transition={{ duration: 0.8, delay: 0.2 }}
             className="glass-panel p-6 sm:p-10 rounded-3xl border-brand-gold/10"
          >
            <form className="flex flex-col gap-5 sm:gap-6" onSubmit={handleSend}>
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest text-zinc-500 font-bold">Name</label>
                <input name="name" type="text" required className="bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-saffron focus:bg-zinc-900 transition backdrop-blur-sm" placeholder="Your name" />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest text-zinc-500 font-bold">Email</label>
                <input name="email" type="email" required className="bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-saffron focus:bg-zinc-900 transition backdrop-blur-sm" placeholder="your@email.com" />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest text-zinc-500 font-bold">Project Type</label>
                <select name="projectType" className="bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-saffron focus:bg-zinc-900 transition appearance-none cursor-pointer backdrop-blur-sm">
                  <option>Original Telugu Song</option>
                  <option>Devotional/Bhakti Track</option>
                  <option>Folk/Janapada</option>
                  <option>Music Production & Beats</option>
                  <option>Custom Event Song</option>
                  <option>Other Collaboration</option>
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-widest text-zinc-500 font-bold">Message</label>
                <textarea name="message" required rows={4} className="bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-saffron focus:bg-zinc-900 transition resize-none backdrop-blur-sm" placeholder="How can we collaborate?..." />
              </div>
              <button type="submit" className="bg-gradient-to-r from-brand-gold to-brand-saffron text-black font-bold uppercase tracking-wider py-4 px-6 rounded-xl mt-2 hover:shadow-[0_0_30px_rgba(255,106,0,0.4)] transition hover:-translate-y-1 active:translate-y-0 text-sm sm:text-base">
                Send Message
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
