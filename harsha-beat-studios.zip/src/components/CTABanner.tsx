import { motion } from 'motion/react';
import { Heart } from 'lucide-react';

export default function CTABanner() {
  return (
    <section className="py-24 md:py-32 relative overflow-hidden flex items-center justify-center border-t border-b border-white/10">
      <div className="absolute inset-0 bg-brand-black" />
      
      {/* Animated waveform loop background */}
      <div className="absolute inset-0 flex items-center justify-center gap-1 md:gap-2 opacity-10 pointer-events-none">
         {[...Array(30)].map((_, i) => (
          <motion.div
            key={`md-${i}`}
            className="w-1 md:w-2 bg-gradient-to-t from-[#FF0000] via-brand-saffron to-[#FF0000] rounded-full hidden md:block"
            animate={{ height: ['20%', '90%', '20%'] }}
            transition={{
              repeat: Infinity,
              duration: 1.5,
              delay: (Math.sin(i / 5) * 0.5) + (i * 0.05),
            }}
          />
        ))}
         {[...Array(15)].map((_, i) => (
          <motion.div
            key={`sm-${i}`}
            className="w-1 md:w-2 bg-gradient-to-t from-[#FF0000] via-brand-saffron to-[#FF0000] rounded-full md:hidden"
            animate={{ height: ['20%', '90%', '20%'] }}
            transition={{
              repeat: Infinity,
              duration: 1.5,
              delay: (Math.sin(i / 3) * 0.5) + (i * 0.1),
            }}
          />
        ))}
      </div>
      
      <div className="relative z-10 text-center px-6 flex flex-col items-center max-w-2xl mx-auto">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-3xl sm:text-4xl md:text-7xl font-display font-black uppercase text-white mb-6 md:mb-8 tracking-tighter"
        >
          Subscribe for <br className="hidden sm:block md:hidden"/> More <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-brand-saffron">Music 🔥</span>
        </motion.h2>
        
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="text-zinc-400 font-light text-sm md:text-lg mb-8 md:mb-10 max-w-sm md:max-w-none"
        >
          Join our growing community on YouTube to get notified the second we drop our next viral lyrical video or devotional track.
        </motion.p>
        
        <motion.a
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          animate={{ boxShadow: ['0 0 20px rgba(255,0,0,0.4)', '0 0 40px rgba(255,0,0,0.6)', '0 0 20px rgba(255,0,0,0.4)'] }}
          href="https://www.youtube.com/@HarshaBeatstudio"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center w-full sm:w-auto gap-3 px-8 md:px-10 py-4 md:py-5 bg-[#FF0000] text-white font-bold tracking-widest uppercase rounded-full hover:bg-red-700 transition-all duration-300 transform hover:scale-105 active:scale-95 text-xs md:text-sm"
        >
           <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16" className="w-5 h-5 md:w-6 md:h-6">
              <path d="M8.051 1.999h.089c.822.003 4.987.033 6.11.335a2.01 2.01 0 0 1 1.415 1.42c.101.38.172.883.22 1.402l.01.104.022.26.008.104c.065.914.073 1.77.074 1.957v.075c-.001.194-.01 1.052-.072 1.96l-.01.104-.022.26-.01.104c-.048.519-.119 1.023-.22 1.402a2.007 2.007 0 0 1-1.415 1.42c-1.16.312-5.569.334-6.18.335h-.142c-.309 0-1.587-.006-2.927-.052l-.17-.006-.087-.004-.171-.007-.171-.007c-1.11-.049-2.167-.128-2.654-.26a2.007 2.007 0 0 1-1.415-1.419c-.111-.417-.185-.986-.235-1.558L.09 9.82l-.008-.104A31.4 31.4 0 0 1 0 7.68v-.123c.002-.215.01-.958.064-1.778l.007-.103.003-.052.008-.104.022-.26.01-.104c.048-.519.119-1.023.22-1.402a2.007 2.007 0 0 1 1.415-1.42c1.16-.312 5.569-.334 6.18-.335h.142Z"/>
              <path d="M5.525 6.595v2.81l2.64-1.405-2.64-1.405Z"/>
            </svg>
          Visit YouTube Channel
        </motion.a>
      </div>
    </section>
  );
}
