import { motion } from 'motion/react';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function LegalPage() {
  const policyCategories = [
    {
      id: "terms",
      title: "Terms and Conditions",
      sections: [
        {
          title: "1. Introduction & Agreement",
          text: "Welcome to Harsha Beat Studios. These Terms and Conditions govern your use of our website, services, audio content, and visuals. By accessing or using our platform, you agree to be bound by these terms. If you do not agree with any part of these terms, please refrain from using our services. Our services cater to audiences accessing our original Telugu songs, devotional tracks, beats, and custom music production."
        },
        {
          title: "2. Intellectual Property & Copyright",
          text: "All content provided by Harsha Beat Studios—including but not limited to music tracks, stems, vocal recordings, beats, visual assets, thumbnails, logos, and written content—is protected by international copyright laws. Harsha Beat Studios retains all ownership rights. Unauthorized downloading, sampling, remixing, distribution, or commercialization of our content without an explicit, verifiable license agreement is strictly prohibited and subject to legal action."
        },
        {
          title: "3. Licensing & Commercial Use",
          text: "If you purchase or acquire a custom beat, arrangement, or song from our studio, the licensing terms will be outlined in a separate written agreement. Streaming our content on platforms like YouTube, Spotify, or Apple Music for personal enjoyment is freely permitted. Utilizing our content in your own YouTube videos, films, or commercial projects requires prior authorization and may require the purchase of a commercial license or sharing of royalties."
        },
        {
           title: "4. AI-Generated & Assisted Content Disclosure",
           text: "Innovation is at the core of Harsha Beat Studios. We openly disclose that certain visual elements, thumbnails, background imagery, and occasionally specific audio processing or compositional ideation may utilize Artificial Intelligence (AI) tools. Approximately 90% of our visual background material involves AI-assisted generation. However, the core emotional intent, editing, final arrangement, and overall creative direction are strictly driven by human artistry to ensure a soulful connection."
        },
        {
          title: "5. User Conduct & Interactions",
          text: "When interacting with our studio via the website contact forms, or commenting on our social platforms, you agree to conduct yourself respectfully. We reserve the right to refuse service to any individual or entity engaging in abusive communication, spam, or inappropriate behavior."
        }
      ]
    },
    {
      id: "privacy",
      title: "Privacy Policy",
      sections: [
        {
          title: "1. Data Collection & Usage",
          text: "Your privacy is paramount. When you fill out our contact form or subscribe to our newsletter, we may collect basic personal information such as your name, email address, and details regarding your musical project. This data is exclusively used to communicate with you, fulfill your service requests, and occasionally provide updates on new music releases or studio offerings."
        },
        {
          title: "2. Data Protection & non-disclosure",
          text: "We implement industry-standard security measures to protect your personal information against unauthorized access, alteration, or disclosure. We assure you that your data is never sold, rented, or traded to third-party marketers or data brokers under any circumstances."
        },
        {
          title: "3. Cookies & Tracking Technologies",
          text: "Our website may utilize 'cookies' and similar tracking technologies to enhance user experience, analyze site traffic, and understand user behavior. Additionally, embedded content from third-party platforms (like YouTube video players) may utilize their own cookies to track views and user interaction, governed by their respective privacy policies."
        },
        {
          title: "4. External Platforms & Third-Party Links",
          text: "Our platform heavily integrates with external services such as YouTube, Instagram, and WhatsApp. Clicking on these links will direct you away from our site. Once you leave Harsha Beat Studios' website, we are no longer responsible for the privacy practices, data collection, or tracking mechanisms of these external platforms."
        }
      ]
    },
    {
      id: "disclaimer",
      title: "Disclaimer",
      sections: [
        {
          title: "1. Content Accuracy & Reliability",
          text: "All musical content, educational materials regarding production, and general information provided on this website are for entertainment and informational purposes only. While we strive for excellence and accuracy, Harsha Beat Studios makes no warranties regarding the completeness, reliability, or absolute accuracy of any information found here."
        },
        {
          title: "2. Limitation of Liability",
          text: "Under no circumstances shall Harsha Beat Studios, its founders, producers, or affiliates be held liable for any direct, indirect, incidental, consequential, or punitive damages arising from the use of our website, the inability to use our services, or any actions taken based on our content. You engage with our platform entirely at your own risk."
        },
        {
          title: "3. Earnings & Success Disclaimer",
          text: "If we provide custom music, beats, or production services for your channel or project, we do not guarantee specific outcomes, such as virality, increased subscriber counts, or financial earnings on platforms like YouTube. Your success depends on your own efforts, marketing, and the overall quality of your complete content."
        },
        {
          title: "4. Policy Modifications",
          text: "We reserve the right to amend, alter, or update these Terms and Conditions, Privacy Policy, and Disclaimers at any time without prior notice. Any changes will be immediately effective upon posting on this page. Your continued use of the website following any updates constitutes your acceptance of the revised policies."
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-brand-black text-white font-sans selection:bg-brand-gold selection:text-black pt-36 pb-20">
      <div className="max-w-4xl mx-auto px-6">
        <Link to="/" className="inline-flex items-center gap-2 text-brand-gold hover:text-white transition mb-12 group">
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
          <span className="font-bold uppercase tracking-widest text-sm">Back to Home</span>
        </Link>

        <header className="mb-16">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-display font-black uppercase tracking-tighter mb-4"
          >
            Legal & <span className="text-brand-gold">Policies</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-zinc-400 text-xl font-light max-w-2xl"
          >
            Detailed information regarding our terms of service, privacy practices, and operational disclaimers.
          </motion.p>
          
          {/* Page Navigation */}
          <motion.div 
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ delay: 0.2 }}
             className="flex flex-wrap gap-4 mt-8"
          >
            {policyCategories.map((cat) => (
               <a 
                 key={cat.id} 
                 href={`#${cat.id}`}
                 className="px-6 py-2 rounded-full border border-white/10 hover:border-brand-gold hover:bg-brand-gold/10 transition-colors text-sm font-bold uppercase tracking-widest text-zinc-300 hover:text-white"
               >
                 {cat.title}
               </a>
            ))}
          </motion.div>
        </header>

        <div className="space-y-20">
          {policyCategories.map((category, catIdx) => (
             <motion.div 
               key={category.id}
               id={category.id}
               initial={{ opacity: 0, y: 20 }}
               whileInView={{ opacity: 1, y: 0 }}
               viewport={{ once: true, margin: "-100px" }}
               className="scroll-mt-32"
             >
               <h2 className="text-3xl md:text-4xl font-display font-black uppercase tracking-tight text-white mb-8 border-b border-white/10 pb-4">
                 {category.title}
               </h2>
               
               <div className="space-y-10">
                 {category.sections.map((section, idx) => (
                   <div key={idx} className="bg-white/[0.02] p-6 lg:p-8 rounded-2xl border border-white/5 hover:border-brand-gold/20 transition-colors">
                     <h3 className="text-xl font-bold text-brand-gold uppercase tracking-wider mb-4">
                       {section.title}
                     </h3>
                     <p className="text-zinc-300 leading-relaxed text-lg font-light">
                       {section.text}
                     </p>
                   </div>
                 ))}
               </div>
             </motion.div>
          ))}
        </div>
        
        <motion.div 
           initial={{ opacity: 0 }}
           whileInView={{ opacity: 1 }}
           viewport={{ once: true }}
           className="mt-20 pt-10 border-t border-white/10 text-center"
        >
          <p className="text-zinc-500 font-light italic">
            Last updated: May 2026. For further inquiries, please use the contact form on our home page.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
