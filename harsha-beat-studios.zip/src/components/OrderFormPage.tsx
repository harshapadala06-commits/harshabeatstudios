import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { MessageCircle, Sparkles, CheckCircle2, ShieldCheck, FileText, Music, Video, Star } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

const eventTypes = [
  "Marriage",
  "Birthday",
  "Anniversary",
  "Engagement",
  "Party",
  "Friendship",
  "Love Proposal",
  "Baby Shower",
  "Festival",
  "Other"
];

export default function OrderFormPage() {
  const [searchParams] = useSearchParams();
  const initialPlan = searchParams.get('plan') || 'Only Audio Song';

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    instagram: '',
    eventType: 'Marriage',
    customEventType: '',
    songType: initialPlan,
    songName: '',
    message: ''
  });

  const [agreedToTerms, setAgreedToTerms] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.phone.length !== 10) {
      alert("Please enter a valid 10-digit mobile number.");
      return;
    }
    if (!agreedToTerms) {
      alert("Please accept the terms and conditions to continue.");
      return;
    }
    const text = `Hello Harsha Beat Studios! I want to order a custom song.

Name: ${formData.name}
Phone: ${formData.phone}${formData.instagram ? `\nInstagram ID: ${formData.instagram}` : ''}
Event Type: ${formData.eventType === 'Other' ? formData.customEventType : formData.eventType}
Song Type: ${formData.songType}
Song Name: ${formData.songName}
Special Message: ${formData.message}`;

    window.open(`https://wa.me/918688203712?text=${encodeURIComponent(text)}`, "_blank");
  };

  const steps = [
    { title: "Complete Booking", desc: "Submit your requirements below.", icon: FileText },
    { title: "Lyrics Review", desc: "You'll get song lyrics after confirmation. (100% refund if you don't like the lyrics)", icon: FileText },
    { title: "50% Advance", desc: "Pay 50% to start the tune. (Amount cannot be refunded once tuning begins)", icon: ShieldCheck },
    { title: "Tuning & Production", desc: "The final tune will be shared. For video plans, custom video will be added.", icon: Music },
    { title: "Final Delivery", desc: "Delivery of the final product and the order invoice.", icon: Star },
  ];

  return (
    <section className="pt-40 pb-24 bg-zinc-950 min-h-screen relative overflow-hidden">
      {/* Cinematic Background Glows */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-brand-gold/10 via-zinc-950 to-zinc-950 opacity-40 pointer-events-none"></div>
      <div className="absolute top-1/4 -left-1/4 w-[500px] h-[500px] bg-brand-saffron/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 -right-1/4 w-[500px] h-[500px] bg-brand-gold/20 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-6 relative z-10">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-brand-gold/30 bg-brand-gold/10 text-brand-gold mb-6 backdrop-blur-md"
          >
            <Sparkles size={16} />
            <span className="text-xs font-bold uppercase tracking-widest">Complete Your Order</span>
          </motion.div>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-display font-black uppercase tracking-tighter text-white mb-4"
          >
             Custom <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-brand-saffron">Song Details</span>
          </motion.h1>
          <motion.div
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             transition={{ delay: 0.2 }}
             className="flex flex-col items-center gap-3"
          >
             <p className="text-zinc-400 text-lg md:text-xl font-light">
               Provide your details and complete the request via WhatsApp
             </p>
             <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-zinc-300 text-sm font-medium">
               <span className="w-2 h-2 rounded-full bg-brand-saffron animate-pulse" />
               Expected Delivery: 5 to 10 Days
             </div>
          </motion.div>
        </div>

        {/* Steps to Book */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="mb-12 glass-panel p-6 rounded-3xl border border-white/10"
        >
          <h3 className="text-lg font-display font-bold text-white mb-6 uppercase tracking-wider text-center">Steps to Book Your Song</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
            {steps.map((step, idx) => (
              <div key={idx} className="flex flex-col items-center text-center p-4 bg-zinc-900/50 rounded-2xl border border-white/5 relative">
                {idx !== steps.length - 1 && (
                  <div className="hidden md:block absolute top-10 -right-2 w-full border-t border-dashed border-white/20 -z-10" />
                )}
                <div className="w-12 h-12 rounded-full bg-brand-gold/10 text-brand-gold flex items-center justify-center mb-3">
                  <step.icon size={20} />
                </div>
                <h4 className="text-sm font-bold text-white mb-2">{step.title}</h4>
                <p className="text-xs text-zinc-400">{step.desc}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <form onSubmit={handleSubmit}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="glass-panel p-6 md:p-10 rounded-3xl border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] relative bg-brand-black/80 backdrop-blur-xl"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-400">Customer Name *</label>
                <input required type="text" name="name" value={formData.name} onChange={handleChange} className="w-full bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all placeholder:text-zinc-700" placeholder="Enter your full name" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-400">Phone Number *</label>
                <input required type="tel" name="phone" value={formData.phone} onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '');
                  if (val.length <= 10) {
                    handleChange({ target: { name: 'phone', value: val } } as any);
                  }
                }} 
                pattern="[0-9]{10}"
                minLength={10}
                maxLength={10}
                title="Please enter a valid 10-digit mobile number"
                className="w-full bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all placeholder:text-zinc-700" placeholder="10-digit mobile number" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-400">Instagram ID (Optional)</label>
                <input type="text" name="instagram" value={formData.instagram} onChange={handleChange} className="w-full bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all placeholder:text-zinc-700" placeholder="@username" />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-400">Event Type *</label>
                <select required name="eventType" value={formData.eventType} onChange={handleChange} className="w-full bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all appearance-none">
                  {eventTypes.map(type => (
                    <option key={type} value={type} className="bg-zinc-900 text-white">{type}</option>
                  ))}
                </select>
              </div>
              {formData.eventType === 'Other' && (
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-zinc-400">Specify Event Type *</label>
                  <input required type="text" name="customEventType" value={formData.customEventType} onChange={handleChange} className="w-full bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all placeholder:text-zinc-700" placeholder="E.g. Graduation" />
                </div>
              )}
               <div className="space-y-2 md:col-span-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-400">Selected Plan</label>
                <input readOnly type="text" name="songType" value={formData.songType} className="w-full bg-brand-gold/10 border border-brand-gold/30 rounded-xl px-4 py-3 text-brand-gold font-bold focus:outline-none cursor-not-allowed" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-400">Custom Song Name *</label>
                <input required type="text" name="songName" value={formData.songName} onChange={handleChange} className="w-full bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all placeholder:text-zinc-700" placeholder="E.g. A Tribute to My Parents" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-xs font-bold uppercase tracking-widest text-zinc-400">Special Message / Lyrics Idea *</label>
                <textarea required name="message" value={formData.message} onChange={handleChange} rows={4} className="w-full bg-zinc-900/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all placeholder:text-zinc-700 resize-none" placeholder="Tell us what the song should be about, any specific names or memories to include..."></textarea>
              </div>
            </div>

            <div className="mb-8 p-6 bg-black/40 rounded-xl border border-white/5 text-sm text-zinc-300">
              <div className="leading-relaxed mb-6 space-y-4">
                <p className="font-bold text-white md:text-base">Terms and Conditions:</p>
                <ul className="list-disc pl-5 space-y-2">
                  <li>A <strong>50% advance</strong> is required after lyrics confirmation.</li>
                  <li>The advance amount is <strong>non-refundable</strong> once tuning begins.</li>
                  <li><span className="text-brand-saffron font-bold">Important Note:</span> No song will be delivered within 1 to 2 days. The minimum production time is 5 days. For event-specific songs, please place your order at least 10 days in advance.</li>
                  <li><span className="text-brand-gold font-semibold">Official Invoice:</span> After delivery of the product, you will also receive an official order invoice from our company.</li>
                </ul>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                <input 
                  type="checkbox" 
                  id="terms" 
                  checked={agreedToTerms}
                  onChange={(e) => setAgreedToTerms(e.target.checked)}
                  className="w-5 h-5 accent-brand-gold bg-zinc-900 border-white/20 rounded cursor-pointer shrink-0"
                />
                <label htmlFor="terms" className="text-sm font-bold text-white cursor-pointer select-none">
                  I accept all the terms and conditions mentioned above.
                </label>
              </div>
            </div>

            <div className="flex flex-col items-center pt-4 border-t border-white/10">
              <button
                type="submit"
                disabled={!agreedToTerms}
                className={`group relative inline-flex items-center justify-center gap-3 px-8 mx-auto w-full md:w-auto py-4 bg-gradient-to-r from-brand-gold to-brand-saffron rounded-full text-zinc-950 font-bold uppercase tracking-widest text-sm transition-all duration-300 z-20 ${!agreedToTerms ? 'opacity-50 cursor-not-allowed grayscale' : 'hover:scale-105 shadow-[0_0_30px_rgba(255,215,0,0.3)] hover:shadow-[0_0_50px_rgba(255,215,0,0.5)]'}`}
              >
                Continue to WhatsApp
                <MessageCircle size={18} className="group-hover:scale-110 transition-transform" />
              </button>
              <p className="text-zinc-500 text-xs mt-4 text-center max-w-md">
                Clicking continue will open a prefilled message in our WhatsApp chat. Please send the message to confirm your order!
              </p>
            </div>
          </motion.div>
        </form>
      </div>
    </section>
  );
}
