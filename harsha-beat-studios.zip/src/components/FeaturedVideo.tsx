import { motion } from 'motion/react';
import { Play } from 'lucide-react';
import { useState, useEffect } from 'react';

const featuredVideos = [
  {
    id: 7,
    videoId: 'V0aNwC-Uk1M',
  },
  {
    id: 1,
    videoId: 'DXRKmQ_gxPE',
  },
  {
    id: 2,
    videoId: 'y90fjMWI8Yo',
  },
  {
    id: 3,
    videoId: 'poBGESlLT4M',
  },
  {
    id: 4,
    videoId: 'sPIhR8UR75s',
  },
  {
    id: 5,
    videoId: 'IkAMhF0ijvI',
  },
  {
    id: 6,
    videoId: 'j7mo6X2C9Oc',
  }
];

export default function FeaturedVideo() {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto-scroll slides
  useEffect(() => {
    const slideTimer = setInterval(() => {
      setCurrentIndex((prev) => {
        const nextIndex = (prev + 1) % featuredVideos.length;
        const slider = document.getElementById('featured-slider');
        if (slider) {
          slider.scrollTo({ left: slider.clientWidth * nextIndex, behavior: 'smooth' });
        }
        return nextIndex;
      });
    }, 5000);
    return () => clearInterval(slideTimer);
  }, []);

  return (
    <section id="latest-release" className="pt-10 pb-20 lg:py-24 relative overflow-hidden">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center justify-center gap-2 text-brand-saffron font-bold uppercase tracking-widest text-sm mb-4"
          >
            <span className="text-xl">🔥</span> Latest Release
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-display font-black uppercase text-white"
          >
            Watch <span className="text-brand-gold">Now</span>
          </motion.h2>
        </div>

        <div className="relative w-full">
          <div className="overflow-hidden p-2">
            <div 
              id="featured-slider"
              className="flex items-stretch overflow-x-auto snap-x snap-mandatory hide-scrollbar pb-4"
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
              onScroll={(e) => {
                const scrollLeft = e.currentTarget.scrollLeft;
                const width = e.currentTarget.clientWidth;
                const newIndex = Math.round(scrollLeft / width);
                if (newIndex !== currentIndex) {
                   setCurrentIndex(newIndex);
                }
              }}
            >
              <style dangerouslySetInnerHTML={{__html: `
                #featured-slider::-webkit-scrollbar { display: none; }
              `}} />
              {featuredVideos.map((video, idx) => (
                <div key={video.id} className="min-w-full px-2 md:px-4 shrink-0 flex justify-center snap-center">
                  <motion.div
                    className="relative w-full rounded-3xl overflow-hidden glass-panel border-2 border-brand-gold/30 shadow-[0_0_50px_rgba(255,215,0,0.3)] group pointer-events-auto"
                  >
                    <div className="aspect-video relative bg-zinc-900 pointer-events-auto">
                      <iframe 
                        src={`https://www.youtube.com/embed/${video.videoId}`} 
                        title="YouTube video player" 
                        frameBorder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                        allowFullScreen
                        className="absolute inset-0 w-full h-full pointer-events-auto"
                      ></iframe>
                    </div>
                  </motion.div>
                </div>
              ))}
            </div>
          </div>

          {/* Slider Indicators */}
          <div className="flex justify-center items-center gap-3 mt-4">
            {featuredVideos.map((_, idx) => (
              <button
                key={idx}
                onClick={() => {
                  const slider = document.getElementById('featured-slider');
                  if (slider) {
                    slider.scrollTo({ left: slider.clientWidth * idx, behavior: 'smooth' });
                  }
                  setCurrentIndex(idx);
                }}
                aria-label={`Go to slide ${idx + 1}`}
                className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                  currentIndex === idx 
                    ? 'w-8 bg-brand-saffron shadow-[0_0_10px_rgba(255,215,0,0.5)]' 
                    : 'bg-white/20 hover:bg-white/40'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

