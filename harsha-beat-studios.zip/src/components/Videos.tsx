import { motion } from 'motion/react';

export default function Videos() {
  return (
    <section id="our-collection" className="py-24 bg-zinc-950 relative overflow-hidden">
       {/* Decorative Lines */}
       <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-brand-gold/30 to-transparent" />
       
       <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-display font-black uppercase tracking-tighter text-white mb-12 text-center">
          Our Upcoming <span className="text-brand-saffron">Projects</span>
        </h2>

        <div className="relative w-full max-w-4xl mx-auto flex justify-center py-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="group relative rounded-3xl overflow-hidden shadow-[0_0_40px_rgba(255,215,0,0.15)] flex flex-col bg-brand-black/90 backdrop-blur-sm w-full border border-brand-gold/30"
          >
            <img 
              src="https://chatgpt.com/backend-api/estuary/content?id=file_0000000019f071faa5154b1c5b40b322&ts=494240&p=fs&cid=1&sig=e7287cabff5938368f649a8eca11d2d2471922087130f6389ff485c5559e3eb3&v=0" 
              alt="Upcoming Albums" 
              loading="lazy"
              className="w-full h-auto object-cover transition-transform duration-1000 group-hover:scale-105"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
