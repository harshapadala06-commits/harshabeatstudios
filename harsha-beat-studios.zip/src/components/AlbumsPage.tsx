import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

const albums = [
  {
    id: 7,
    videoId: 'V0aNwC-Uk1M',
    title: 'New Release',
  },
  {
    id: 1,
    videoId: 'DXRKmQ_gxPE',
    title: 'Nee Sannidhi',
  },
  {
    id: 2,
    videoId: 'y90fjMWI8Yo',
    title: 'Latest Release',
  },
  {
    id: 3,
    videoId: 'j7mo6X2C9Oc',
    title: 'New Lyrical Video',
  },
  {
    id: 4,
    videoId: 'poBGESlLT4M',
    title: 'Rudra Tandava Tarangam',
  },
  {
    id: 5,
    videoId: 'IkAMhF0ijvI',
    title: 'Srirama Lyrical Video',
  },
  {
    id: 6,
    videoId: 'sPIhR8UR75s',
    title: 'Amma - Thyagamayi ❤️ | Mother’s Day Special song 2026',
  }
];

export default function AlbumsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const filteredAlbums = albums.filter((album) =>
    album.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-brand-black pt-32 md:pt-36">
      <div className="max-w-7xl mx-auto px-0 md:px-6 py-6 md:py-12">
        <div className="px-4 md:px-0 mb-6 md:mb-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h1 className="text-2xl md:text-5xl font-display font-black uppercase tracking-tighter text-white">
                Our <span className="text-brand-saffron">Albums</span>
            </h1>
            
            <div className="flex-1 max-w-md w-full relative">
              <div className="relative flex items-center">
                <Search className="absolute left-3 text-zinc-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search albums..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                  className="w-full bg-zinc-900/50 border border-white/10 rounded-full py-2.5 pl-10 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:border-brand-saffron focus:bg-zinc-900 transition backdrop-blur-sm text-sm"
                />
              </div>
              
              {/* Search Suggestions Dropdown */}
              <AnimatePresence>
                {isSearchFocused && searchQuery && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute w-full mt-2 bg-zinc-900 border border-white/10 rounded-2xl shadow-xl z-50 overflow-hidden"
                  >
                    {filteredAlbums.length > 0 ? (
                      <ul className="py-2">
                        {filteredAlbums.map(album => (
                          <li key={album.id}>
                            <a 
                              href={`https://youtu.be/${album.videoId}`} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-3 px-4 py-2 hover:bg-white/5 transition-colors cursor-pointer"
                            >
                              <Search className="w-4 h-4 text-zinc-500" />
                              <span className="text-sm text-white">{album.title}</span>
                            </a>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <div className="p-4 text-sm text-zinc-500 text-center">No results found</div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Link to="/" className="text-xs md:text-sm font-bold uppercase tracking-widest text-zinc-400 hover:text-white transition whitespace-nowrap hidden md:block">
                &larr; Back to Home
            </Link>
        </div>

        {/* Mobile: YouTube style vertical feed, Desktop: Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 gap-y-10 md:gap-y-12 px-4 md:px-0">
          {filteredAlbums.map((album, idx) => (
            <motion.div
              key={album.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="group flex flex-col"
            >
              <div className="relative w-full aspect-video md:rounded-xl overflow-hidden bg-zinc-900 border border-white/5 md:border-white/10">
                <iframe
                  width="100%"
                  height="100%"
                  src={`https://www.youtube.com/embed/${album.videoId}`}
                  title={album.title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full h-full"
                ></iframe>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
