import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-brand-black border-t border-white/5 py-12">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2">
          <div className="font-display font-black text-xl tracking-tighter uppercase flex items-center opacity-80">
            <span className="text-brand-gold">H</span>
            <span className="text-brand-blue">B</span>
          </div>
          <div className="flex flex-col ml-2 leading-none opacity-80">
            <span className="font-display font-bold text-sm tracking-wider">HARSHA BEAT</span>
            <span className="text-[8px] tracking-[0.2em] text-zinc-500 uppercase">Studios</span>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-8 text-sm text-zinc-400 font-medium">
          <Link to="/#latest-release" className="hover:text-brand-gold transition">Latest Release</Link>
          <Link to="/#collection" className="hover:text-brand-gold transition">Collection</Link>
          <Link to="/#about" className="hover:text-brand-gold transition">About</Link>
          <Link to="/#contact" className="hover:text-brand-gold transition">Contact</Link>
          <Link to="/legal" className="hover:text-brand-gold transition">Legal & Policies</Link>
        </div>

        <div className="text-zinc-600 text-xs text-center md:text-right">
          &copy; {new Date().getFullYear()} Harsha Beat Studios. <br className="md:hidden" />All rights reserved.
        </div>
      </div>
    </footer>
  );
}
