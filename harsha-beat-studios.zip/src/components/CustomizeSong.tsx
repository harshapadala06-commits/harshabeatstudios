import { motion } from 'motion/react';
import { Sparkles, Music, Video, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const songOptions = [
  {
    id: "Only Audio Song",
    title: "Only Audio Song",
    icon: Music,
    originalPrice: "₹9999",
    offerPrice: "₹3999",
    features: ["Custom Lyrics", "High Quality Audio", "Professional Vocals"]
  },
  {
    id: "Video Song",
    title: "Video Song",
    icon: Video,
    originalPrice: "₹15000",
    offerPrice: "₹5999",
    features: ["Everything in Audio", "Cinematic Lyrical Video", "Perfect for YouTube/Reels"],
    recommended: true
  }
];

export default function CustomizeSong() {
  const navigate = useNavigate();

  return (
    <section id="customize" className="py-24 bg-zinc-950 relative overflow-hidden">
      {/* Cinematic Background Glows */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-brand-gold/10 via-zinc-950 to-zinc-950 opacity-40 pointer-events-none"></div>
      <div className="absolute top-1/4 -left-1/4 w-[500px] h-[500px] bg-brand-saffron/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 -right-1/4 w-[500px] h-[500px] bg-brand-gold/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-brand-gold/30 to-transparent" />

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-brand-gold/30 bg-brand-gold/10 text-brand-gold mb-6 backdrop-blur-md"
          >
            <Sparkles size={16} />
            <span className="text-xs font-bold uppercase tracking-widest">Premium Service</span>
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-display font-black uppercase tracking-tighter text-white mb-4"
          >
            Customize Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-brand-saffron">Song</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-zinc-400 text-lg md:text-xl max-w-2xl mx-auto font-light"
          >
            Create unforgettable memories with personalized songs from Harsha Beat Studios
          </motion.p>
        </div>

        <div className="max-w-5xl mx-auto">
          {/* Output Cards */}
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {songOptions.map((option, idx) => (
              <motion.div
                key={option.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 * idx }}
                onClick={() => navigate(`/order?plan=${encodeURIComponent(option.id)}`)}
                className="relative cursor-pointer rounded-3xl p-6 md:p-8 border-2 transition-all duration-300 glass-panel overflow-hidden group border-white/10 hover:border-brand-gold/50 hover:shadow-[0_0_30px_rgba(255,215,0,0.2)] hover:bg-brand-gold/5"
              >
                {/* Selection Indicator */}
                <div className="absolute top-6 right-6 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors border-white/30 group-hover:border-brand-gold">
                  <CheckCircle2 size={16} className="text-transparent group-hover:text-brand-gold" />
                </div>

                {option.recommended && (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-gradient-to-r from-brand-gold to-brand-saffron text-zinc-950 text-xs font-bold px-4 py-1 rounded-b-lg uppercase tracking-wider shadow-[0_0_15px_rgba(255,215,0,0.4)]">
                    Most Popular
                  </div>
                )}

                <div className="flex items-center gap-4 mb-6">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-white/10 text-white group-hover:bg-brand-gold group-hover:text-zinc-950 transition-colors">
                    <option.icon size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl md:text-2xl font-display font-bold text-white">{option.title}</h3>
                  </div>
                </div>

                <div className="mb-6 flex flex-col">
                  <span className="text-zinc-500 line-through text-lg">{option.originalPrice}</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-brand-gold to-brand-saffron drop-shadow-sm">{option.offerPrice}</span>
                    <span className="text-zinc-400 text-sm uppercase tracking-wider font-bold">Only</span>
                  </div>
                </div>

                <ul className="space-y-3">
                  {option.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3 text-zinc-300">
                      <CheckCircle2 size={18} className="text-brand-gold flex-shrink-0" />
                      <span className="text-sm md:text-base">{feature}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

       {/* Sticky CTA for Mobile (Optional, requested) */}
       <div className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 w-[90%] pointer-events-none flex justify-center">
          <div className="pointer-events-auto w-full max-w-sm rounded-full bg-zinc-950/90 backdrop-blur-md border border-brand-gold shadow-[0_0_30px_rgba(255,215,0,0.4)] px-4 py-2 flex items-center justify-between">
             <div className="flex flex-col">
                <span className="text-[11px] font-black text-brand-gold uppercase tracking-widest block leading-tight mb-[2px]">
                  Book Your Customized Songs
                </span>
                <span className="text-[9px] text-zinc-400 uppercase tracking-widest block leading-none">
                  Starting from ₹3999
                </span>
             </div>
             <button
               onClick={() => {
                 document.getElementById('customize')?.scrollIntoView({ behavior: 'smooth' });
               }}
               className="bg-gradient-to-r from-brand-gold to-brand-saffron text-zinc-950 px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center shadow-[0_0_15px_rgba(255,215,0,0.5)] whitespace-nowrap ml-2 shrink-0"
             >
               View Plans
             </button>
          </div>
       </div>

    </section>
  );
}
