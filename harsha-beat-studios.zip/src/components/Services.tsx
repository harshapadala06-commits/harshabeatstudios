import { motion } from 'motion/react';
import { Music, Mic2, Star, Radio, Heart, Headphones } from 'lucide-react';

const services = [
  {
    title: 'AI-Assisted Music Production',
    icon: <Music className="w-8 h-8" />,
    description: 'High-quality music tracks created with advanced AI tools and human artistry for precise emotive resonance.'
  },
  {
    title: 'Lyrical Video Creation',
    icon: <Radio className="w-8 h-8" />,
    description: 'Engaging and visually stunning lyrical videos perfectly synced with your tracks for maximum audience retention.'
  },
  {
    title: 'Cinematic Visual Design',
    icon: <Star className="w-8 h-8" />,
    description: 'Striking cinematic visuals and thumbnails designed to catch attention and compliment your digital content.'
  },
  {
    title: 'High-quality Audio Engineering',
    icon: <Headphones className="w-8 h-8" />,
    description: 'Industry-standard mixing, mastering, and complete track polishing.'
  },
  {
    title: 'Devotional Songs (Bhakti)',
    icon: <Heart className="w-8 h-8" />,
    description: 'Soulful and impactful devotional tracks for modern spiritual listeners.'
  },
  {
    title: 'Custom Songs for Events',
    icon: <Mic2 className="w-8 h-8" />,
    description: 'Personalized music for creators, weddings, and special events tailored to your needs.'
  }
];

export default function Services() {
  return (
    <section className="py-24 relative overflow-hidden bg-brand-black border-y border-white/5">
      <div className="absolute inset-0 z-0 bg-[radial-gradient(ellipse_at_top,rgba(245,184,65,0.05)_0%,transparent_70%)]" />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center justify-center gap-2 text-brand-gold font-bold uppercase tracking-widest text-sm mb-4"
          >
             Studio Capabilities
          </motion.div>
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-display font-black uppercase text-white tracking-tighter"
          >
            What We <span className="text-brand-saffron">Offer</span>
          </motion.h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="glass-panel p-8 rounded-3xl border border-white/5 hover:border-brand-blue/50 hover:bg-white/[0.02] transition-all group hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(0,194,255,0.1)]"
            >
              <div className="w-16 h-16 rounded-2xl bg-brand-gold/10 text-brand-gold flex items-center justify-center mb-6 group-hover:scale-110 transition-transform group-hover:bg-brand-saffron/20 group-hover:text-brand-saffron">
                {service.icon}
              </div>
              <h2 className="text-xl font-bold text-white mb-3 tracking-wide">{service.title}</h2>
              <p className="text-zinc-400 font-light leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
